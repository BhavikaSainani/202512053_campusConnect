# CampusConnect — Lab 6: Docker & Microservices

**Course:** Web Services and Service-Oriented Architecture (SOA) Laboratory  
**Student ID:** 202512053  
**Tech Stack:** Docker | Docker Compose | Express.js (Node.js 20) | MongoDB | Axios | Postman  

---

## Table of Contents
1. [Project Overview & Relation to Previous Labs](#1-project-overview--relation-to-previous-labs)
2. [Why Microservices? Monolith vs Microservices](#2-why-microservices-monolith-vs-microservices)
3. [Service Boundaries & Responsibilities](#3-service-boundaries--responsibilities)
4. [Microservices Architecture Diagram](#4-microservices-architecture-diagram)
5. [Service Ports & Endpoint Mapping](#5-service-ports--endpoint-mapping)
6. [Database-per-Service Approach](#6-database-per-service-approach)
7. [Step-by-Step Implementation](#7-step-by-step-implementation)
   - [Step 1: Service Decomposition & Project Structure](#step-1--service-decomposition--project-structure)
   - [Step 2: User Service Implementation](#step-2--user-service-implementation)
   - [Step 3: Product Service Implementation](#step-3--product-service-implementation)
   - [Step 4: Order Service & Inter-Service Communication](#step-4--order-service--inter-service-communication)
   - [Step 5: Dockerfile for Each Service](#step-5--dockerfile-for-each-service)
   - [Step 6: Building Docker Images](#step-6--building-docker-images)
   - [Step 7: Docker Network & Service-Name Communication](#step-7--docker-network--service-name-communication)
   - [Step 8: Environment Variables & Service URLs](#step-8--environment-variables--service-urls)
   - [Step 9: Docker Compose Configuration](#step-9--docker-compose-configuration)
   - [Step 10: Running & Verifying with Docker Compose](#step-10--running--verifying-with-docker-compose)
   - [Step 11: Postman Testing & Evidence](#step-11--postman-testing--evidence)
   - [Step 12: Dependency Failure & Recovery (503 Test)](#step-12--dependency-failure--recovery-503-test)
   - [Step 13: Application Teardown](#step-13--application-teardown)
8. [Service-to-Service Communication Flow](#8-service-to-service-communication-flow)
9. [Inter-Service Error Handling](#9-inter-service-error-handling)
10. [API & Communication Exercise](#10-api--communication-exercise)
11. [Docker Commands Reference](#11-docker-commands-reference)
12. [Troubleshooting & Resolution Guide](#12-troubleshooting--resolution-guide)
13. [How to Run Each Service Independently](#13-how-to-run-each-service-independently)
14. [Submission Checklist](#14-submission-checklist)

---

## 1. Project Overview & Relation to Previous Labs

| Lab | Focus | What Was Built |
|-----|-------|----------------|
| **Lab 3** | RESTful Web Services | Express.js Student API with in-memory data |
| **Lab 4** | Multi-client Architecture | REST API + React web client + Android mobile client + MongoDB Atlas |
| **Lab 5** | Docker & Containerization | Dockerized monolithic Student API + MongoDB container + Docker Compose |
| **Lab 6** | **Microservices** | **Decomposed backend into 3 independent services with inter-service communication** |

In **Lab 6**, we transition from a single monolithic Student API to a **microservices-based architecture**:
- The monolithic backend is decomposed into **User Service**, **Product Service**, and **Order Service**.
- Each service is independently runnable, containerized, and responsible for its own data.
- The **Order Service** communicates with User and Product services via REST APIs over a shared Docker network.
- All services are orchestrated using **Docker Compose**.

---

## 2. Why Microservices? Monolith vs Microservices

| Aspect | Monolith (Lab 5) | Microservices (Lab 6) |
|--------|-------------------|----------------------|
| **Codebase** | Single `server.js` with all logic | Separate codebases per service |
| **Deployment** | Deploy entire application | Deploy services independently |
| **Scaling** | Scale entire application | Scale individual services |
| **Database** | Single shared database | Database-per-service isolation |
| **Failure Impact** | Single failure breaks everything | Failures are isolated to one service |
| **Technology** | Single tech stack | Can use different stacks per service |
| **Team Ownership** | Entire team on one codebase | Teams own individual services |

---

## 3. Service Boundaries & Responsibilities

Each service has **one clear responsibility** and remains **independently runnable**.

| Service | Responsibility | Port | Main Resources | Data Ownership |
|---------|---------------|------|-----------------|----------------|
| **User Service** | Create, retrieve, update, and delete User resources | `:3001` | Users | `campusconnect-users` DB |
| **Product Service** | Manage Product resources used by the application | `:3002` | Products | `campusconnect-products` DB |
| **Order Service** | Create and retrieve Orders; validate referenced User and Product data through APIs | `:3003` | Orders | `campusconnect-orders` DB |

---

## 4. Microservices Architecture Diagram

```
+------------------------------------------------------------------------------------+
|                                  HOST MACHINE                                      |
|                                                                                    |
|    +------------------+                                                            |
|    | Client / Postman |                                                            |
|    +--------+---------+                                                            |
|             |                                                                      |
|     HTTP Requests to localhost:3001 / :3002 / :3003                                |
|             |                                                                      |
|    +--------v-----------------------------------------------------------------+    |
|    |                     DOCKER ENGINE / DOCKER COMPOSE                        |    |
|    |                                                                          |    |
|    |    +----------------------------------------------------------------+    |    |
|    |    |              Docker Network: campus-network (Bridge)            |    |    |
|    |    |                                                                |    |    |
|    |    |  +--------------------+  +---------------------+               |    |    |
|    |    |  | Container:         |  | Container:          |               |    |    |
|    |    |  | user-service       |  | product-service     |               |    |    |
|    |    |  | Port: 3001:3001    |  | Port: 3002:3002     |               |    |    |
|    |    |  | DB: campusconnect- |  | DB: campusconnect-  |               |    |    |
|    |    |  |     users          |  |     products        |               |    |    |
|    |    |  +--------^-----------+  +---------^-----------+               |    |    |
|    |    |           |   REST API             |   REST API                |    |    |
|    |    |           |                        |                           |    |    |
|    |    |  +--------+------------------------+-----------+               |    |    |
|    |    |  | Container: order-service                    |               |    |    |
|    |    |  | Port: 3003:3003                             |               |    |    |
|    |    |  | DB: campusconnect-orders                    |               |    |    |
|    |    |  | Env: USER_SERVICE_URL=http://user-service   |               |    |    |
|    |    |  |      PRODUCT_SERVICE_URL=http://product-svc |               |    |    |
|    |    |  +--------------------------------------------+               |    |    |
|    |    |                                                                |    |    |
|    |    |  +--------------------------------------------+               |    |    |
|    |    |  | Container: mongodb                         |               |    |    |
|    |    |  | Port: 27017:27017                          |               |    |    |
|    |    |  | Databases: campusconnect-users              |               |    |    |
|    |    |  |            campusconnect-products           |               |    |    |
|    |    |  |            campusconnect-orders             |               |    |    |
|    |    |  +---------------------+-----------------------+               |    |    |
|    |    +------------------------|-----------------------------------+    |    |
|    |                             v                                        |    |
|    |              +----------------------------------------------+        |    |
|    |              | Named Volume: campus-mongo-data               |        |    |
|    |              | Mount Path: /data/db (Persistent Storage)     |        |    |
|    |              +----------------------------------------------+        |    |
|    +------------------------------------------------------------------+    |
+------------------------------------------------------------------------------------+
```

**Communication Flow:**
- **Client/Postman** → `localhost:3001` → **User Service** (direct)
- **Client/Postman** → `localhost:3002` → **Product Service** (direct)
- **Client/Postman** → `localhost:3003` → **Order Service** (direct)
- **Order Service** → `http://user-service:3001/users/:id` → **User Service** (inter-service, via Docker DNS)
- **Order Service** → `http://product-service:3002/products/:id` → **Product Service** (inter-service, via Docker DNS)

---

## 5. Service Ports & Endpoint Mapping

### User Service (`:3001`)
| Method | Endpoint | Description | Status Code |
|--------|----------|-------------|-------------|
| `GET` | `/` | Health check | `200 OK` |
| `GET` | `/users` | List all users | `200 OK` |
| `GET` | `/users/:id` | Get user by ID | `200 OK` / `404 Not Found` |
| `POST` | `/users` | Create a new user | `201 Created` / `400 Bad Request` |
| `PUT` | `/users/:id` | Update user by ID | `200 OK` / `404 Not Found` |
| `DELETE` | `/users/:id` | Delete user by ID | `200 OK` / `404 Not Found` |

### Product Service (`:3002`)
| Method | Endpoint | Description | Status Code |
|--------|----------|-------------|-------------|
| `GET` | `/` | Health check | `200 OK` |
| `GET` | `/products` | List all products | `200 OK` |
| `GET` | `/products/:id` | Get product by ID | `200 OK` / `404 Not Found` |
| `POST` | `/products` | Create a new product | `201 Created` / `400 Bad Request` |
| `PUT` | `/products/:id` | Update product by ID | `200 OK` / `404 Not Found` |
| `DELETE` | `/products/:id` | Delete product by ID | `200 OK` / `404 Not Found` |

### Order Service (`:3003`)
| Method | Endpoint | Description | Status Code |
|--------|----------|-------------|-------------|
| `GET` | `/` | Health check | `200 OK` |
| `GET` | `/orders` | List all orders | `200 OK` |
| `GET` | `/orders/:id` | Get order by ID | `200 OK` / `404 Not Found` |
| `POST` | `/orders` | Create order (validates user & product via inter-service calls) | `201 Created` / `404` / `503` |

---

## 6. Database-per-Service Approach

Each service owns its data. **No service directly accesses another service's database.**

```
Rule:  Order Service → REST API → User Service    ✅ CORRECT
       Order Service → User Database directly      ❌ PROHIBITED
```

| Service | Database Name | Collections |
|---------|--------------|-------------|
| User Service | `campusconnect-users` | `users` |
| Product Service | `campusconnect-products` | `products` |
| Order Service | `campusconnect-orders` | `orders` |

All three databases reside within the **same MongoDB instance** (container `mongodb`), but each service only connects to its own database via its `MONGO_URI` environment variable.

---

## 7. Step-by-Step Implementation

### Step 1 — Service Decomposition & Project Structure

The monolithic `student-api-express/server.js` from Lab 5 is decomposed into three independent service directories:

```
202512053_campusConnect_Lab6/
├── user-service/
│   ├── server.js          # User REST API
│   ├── package.json       # Dependencies
│   ├── Dockerfile         # Container image recipe
│   └── .dockerignore      # Build context exclusions
├── product-service/
│   ├── server.js          # Product REST API
│   ├── package.json       # Dependencies
│   ├── Dockerfile         # Container image recipe
│   └── .dockerignore      # Build context exclusions
├── order-service/
│   ├── server.js          # Order REST API + inter-service calls
│   ├── package.json       # Dependencies (includes axios)
│   ├── Dockerfile         # Container image recipe
│   └── .dockerignore      # Build context exclusions
├── compose.yaml           # Multi-container orchestration
├── Microservices_Lab_6.postman_collection.json
└── README.md              # This documentation
```

---

### Step 2 — User Service Implementation

**File:** `user-service/server.js`

**User Model Schema:**
```javascript
const userSchema = new mongoose.Schema({
  name:  { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, trim: true },
  phone: { type: String, trim: true, default: '' },
  role:  { type: String, default: 'student', enum: ['student', 'faculty', 'admin'] }
}, { versionKey: false, timestamps: true });
```

**Endpoints:** Full CRUD — `GET /users`, `GET /users/:id`, `POST /users`, `PUT /users/:id`, `DELETE /users/:id`

**Database:** `mongodb://mongodb:27017/campusconnect-users`

---

### Step 3 — Product Service Implementation

**File:** `product-service/server.js`

**Product Model Schema:**
```javascript
const productSchema = new mongoose.Schema({
  name:        { type: String, required: true, trim: true },
  description: { type: String, trim: true, default: '' },
  price:       { type: Number, required: true, min: 0 },
  category:    { type: String, trim: true, default: 'general' },
  stock:       { type: Number, default: 0, min: 0 }
}, { versionKey: false, timestamps: true });
```

**Endpoints:** Full CRUD — `GET /products`, `GET /products/:id`, `POST /products`, `PUT /products/:id`, `DELETE /products/:id`

**Database:** `mongodb://mongodb:27017/campusconnect-products`

---

### Step 4 — Order Service & Inter-Service Communication

**File:** `order-service/server.js`

The Order Service is the **most critical service** for Lab 6 as it demonstrates **service-to-service communication**:

```javascript
// On POST /orders:
// 1. Validate User exists → GET http://user-service:3001/users/:userId
// 2. Validate Product exists → GET http://product-service:3002/products/:productId
// 3. Calculate totalPrice = product.price × quantity
// 4. Save order with enriched user/product data
```

**Order Model Schema:**
```javascript
const orderSchema = new mongoose.Schema({
  userId:       { type: String, required: true },
  productId:    { type: String, required: true },
  quantity:     { type: Number, required: true, min: 1 },
  totalPrice:   { type: Number, default: 0 },
  status:       { type: String, default: 'placed' },
  userName:     { type: String },   // Enriched from User Service
  userEmail:    { type: String },   // Enriched from User Service
  productName:  { type: String },   // Enriched from Product Service
  productPrice: { type: Number }    // Enriched from Product Service
}, { versionKey: false, timestamps: true });
```

**Service URLs (via environment variables):**
```bash
USER_SERVICE_URL=http://user-service:3001
PRODUCT_SERVICE_URL=http://product-service:3002
```

**Database:** `mongodb://mongodb:27017/campusconnect-orders`

---

### Step 5 — Dockerfile for Each Service

Each service uses an identical Dockerfile pattern:

```dockerfile
# Base Image: Lightweight Node.js 20 on Alpine Linux
FROM node:20-alpine

# Set working directory inside the container
WORKDIR /app

# Copy package descriptors first for Docker layer caching
COPY package*.json ./

# Install dependencies inside container image
RUN npm install

# Copy the rest of the application source code
COPY . .

# Expose the service port (3001 / 3002 / 3003)
EXPOSE <PORT>

# Start command
CMD ["node", "server.js"]
```

**Layer Caching Strategy:** By copying `package*.json` and running `npm install` before `COPY . .`, Docker caches the dependency layer. Source code changes rebuild in sub-seconds.

**`.dockerignore`** excludes `node_modules`, `.env`, `.git`, and `npm-debug.log` from the build context.

---

### Step 6 — Building Docker Images

```bash
# Build each service image with a meaningful tag
docker build -t user-service:v1 ./user-service
docker build -t product-service:v1 ./product-service
docker build -t order-service:v1 ./order-service

# Verify all images are built
docker images
```

Expected output:
```
REPOSITORY        TAG     IMAGE ID       SIZE
user-service      v1      ...            ~180MB
product-service   v1      ...            ~180MB
order-service     v1      ...            ~185MB
mongo             latest  ...            ~700MB
```

---

### Step 7 — Docker Network & Service-Name Communication

```bash
# Create the shared bridge network
docker network create campus-network

# Verify the network exists
docker network ls
```

Inside the `campus-network`, Docker's embedded DNS server resolves container names to IP addresses:
- `user-service` → resolves to User Service container IP
- `product-service` → resolves to Product Service container IP
- `mongodb` → resolves to MongoDB container IP

**Important:** `localhost` inside a container refers to the container itself, NOT to other containers. Always use service/container names for inter-container communication.

---

### Step 8 — Environment Variables & Service URLs

| Variable | Service | Value | Purpose |
|----------|---------|-------|---------|
| `PORT` | All | `3001` / `3002` / `3003` | Express listening port |
| `MONGO_URI` | User | `mongodb://mongodb:27017/campusconnect-users` | User DB connection |
| `MONGO_URI` | Product | `mongodb://mongodb:27017/campusconnect-products` | Product DB connection |
| `MONGO_URI` | Order | `mongodb://mongodb:27017/campusconnect-orders` | Order DB connection |
| `USER_SERVICE_URL` | Order | `http://user-service:3001` | Target URL for User validation |
| `PRODUCT_SERVICE_URL` | Order | `http://product-service:3002` | Target URL for Product validation |

**Verification:** Change a port or target URL through configuration (environment variable) without changing application source code.

---

### Step 9 — Docker Compose Configuration

**File:** `compose.yaml`

```yaml
services:
  user-service:
    build: ./user-service
    container_name: user-service
    ports: ["3001:3001"]
    environment:
      PORT: 3001
      MONGO_URI: mongodb://mongodb:27017/campusconnect-users
    depends_on: [mongodb]
    networks: [campus-network]
    restart: unless-stopped

  product-service:
    build: ./product-service
    container_name: product-service
    ports: ["3002:3002"]
    environment:
      PORT: 3002
      MONGO_URI: mongodb://mongodb:27017/campusconnect-products
    depends_on: [mongodb]
    networks: [campus-network]
    restart: unless-stopped

  order-service:
    build: ./order-service
    container_name: order-service
    ports: ["3003:3003"]
    environment:
      PORT: 3003
      MONGO_URI: mongodb://mongodb:27017/campusconnect-orders
      USER_SERVICE_URL: http://user-service:3001
      PRODUCT_SERVICE_URL: http://product-service:3002
    depends_on: [mongodb, user-service, product-service]
    networks: [campus-network]
    restart: unless-stopped

  mongodb:
    image: mongo:latest
    container_name: mongodb
    ports: ["27017:27017"]
    volumes: [campus-mongo-data:/data/db]
    networks: [campus-network]
    restart: unless-stopped

volumes:
  campus-mongo-data:
    name: campus-mongo-data

networks:
  campus-network:
    name: campus-network
    driver: bridge
```

---

### Step 10 — Running & Verifying with Docker Compose

```bash
# Validate the compose configuration
docker compose config

# Build images and start all services in detached mode
docker compose up -d --build

# Verify all containers are running
docker compose ps

# View unified logs from all services
docker compose logs -f

# View logs from a specific service
docker compose logs user-service
docker compose logs order-service
```

Expected `docker compose ps` output:
```
NAME              COMMAND          SERVICE           STATUS          PORTS
user-service      "node server.js" user-service      Up              0.0.0.0:3001->3001/tcp
product-service   "node server.js" product-service   Up              0.0.0.0:3002->3002/tcp
order-service     "node server.js" order-service     Up              0.0.0.0:3003->3003/tcp
mongodb           "mongod"         mongodb           Up              0.0.0.0:27017->27017/tcp
```

---

### Step 11 — Postman Testing & Evidence

Import `Microservices_Lab_6.postman_collection.json` into Postman.

| # | Test | Method | Endpoint | Expected |
|---|------|--------|----------|----------|
| 1 | Health – User Service | `GET` | `localhost:3001/` | `200 OK` |
| 2 | Health – Product Service | `GET` | `localhost:3002/` | `200 OK` |
| 3 | Health – Order Service | `GET` | `localhost:3003/` | `200 OK` |
| 4 | Create User | `POST` | `localhost:3001/users` | `201 Created` |
| 5 | Get All Users | `GET` | `localhost:3001/users` | `200 OK` |
| 6 | Create Product | `POST` | `localhost:3002/products` | `201 Created` |
| 7 | Get All Products | `GET` | `localhost:3002/products` | `200 OK` |
| 8 | **Create Order (valid)** | `POST` | `localhost:3003/orders` | `201 Created` — inter-service success |
| 9 | Get All Orders | `GET` | `localhost:3003/orders` | `200 OK` — shows enriched data |
| 10 | Order – Invalid User ID | `POST` | `localhost:3003/orders` | `404 Not Found` |
| 11 | Order – Invalid Product ID | `POST` | `localhost:3003/orders` | `404 Not Found` |
| 12 | **Order – User Service Down** | `POST` | `localhost:3003/orders` | `503 Service Unavailable` |
| 13 | **Order – After Recovery** | `POST` | `localhost:3003/orders` | `201 Created` — recovery verified |

---

### Step 12 — Dependency Failure & Recovery (503 Test)

```bash
# 1. Stop User Service
docker stop user-service

# 2. Try creating an order → Should return 503 Service Unavailable
# (via Postman POST localhost:3003/orders)

# 3. Restart User Service
docker start user-service

# 4. Try creating an order again → Should return 201 Created (recovery)
```

---

### Step 13 — Application Teardown

```bash
# Stop and remove all containers and networks (preserves volumes)
docker compose down

# To also remove persistent volumes (fresh start):
docker compose down -v

# Remove built images
docker rmi user-service:v1 product-service:v1 order-service:v1
```

---

## 8. Service-to-Service Communication Flow

```
POST /orders { userId: "abc", productId: "xyz", quantity: 3 }
          |
          v
   [Order Service :3003]
          |
          |── GET http://user-service:3001/users/abc ──→ [User Service :3001]
          |                                                    │
          |                                              User found? ──→ { name, email }
          |                                              Not found?  ──→ 404
          |                                              Unavailable ──→ 503
          |
          |── GET http://product-service:3002/products/xyz ──→ [Product Service :3002]
          |                                                          │
          |                                                    Product found? ──→ { name, price }
          |                                                    Not found?     ──→ 404
          |                                                    Unavailable    ──→ 503
          |
          v
   totalPrice = product.price × quantity
   Save Order with enriched user/product data
          |
          v
   201 Created { id, userId, productId, quantity, totalPrice, userName, productName, ... }
```

---

## 9. Inter-Service Error Handling

| Scenario | Behavior | HTTP Status |
|----------|----------|-------------|
| User/Product found successfully | Order created with enriched data | `201 Created` |
| User ID not found in User Service | Clear error message returned | `404 Not Found` |
| Product ID not found in Product Service | Clear error message returned | `404 Not Found` |
| User Service container is stopped/unreachable | Controlled failure with descriptive error | `503 Service Unavailable` |
| Product Service container is stopped/unreachable | Controlled failure with descriptive error | `503 Service Unavailable` |
| Request timeout (5 seconds) | Stops waiting after limit | `503 Service Unavailable` |

**Concepts (introduced for awareness, not fully implemented):**
| Pattern | Description |
|---------|-------------|
| **Timeout** | Stop waiting after 5 seconds (implemented via axios timeout) |
| **Retry** | Limited repeat attempt on transient failures |
| **Fallback** | Return a safe alternative response |
| **Circuit Breaker** | Open circuit after repeated failures to prevent cascading |

---

## 10. API & Communication Exercise

### Service Design Table

| Item | User Service | Product Service | Order Service |
|------|-------------|-----------------|---------------|
| **Responsibility** | Manage user accounts | Manage product catalog | Create & track orders |
| **Port** | `:3001` | `:3002` | `:3003` |
| **Main Resources** | Users | Products | Orders |
| **Key Endpoints** | GET/POST/PUT/DELETE `/users` | GET/POST/PUT/DELETE `/products` | POST/GET `/orders` |
| **Database** | `campusconnect-users` | `campusconnect-products` | `campusconnect-orders` |

### Service-to-Service Call Design

| Field | Design |
|-------|--------|
| **Calling Service** | Order Service |
| **Target Service** | User Service / Product Service |
| **HTTP Method** | `GET` |
| **Endpoint** | `/users/{id}` or `/products/{id}` |
| **Request Data** | Referenced user/product ID from order body |
| **Expected Response** | `200 OK` + requested resource JSON |
| **Failure Response** | `404` for invalid resource; `503` when dependency is unavailable |

---

## 11. Docker Commands Reference

| Command | Purpose |
|---------|---------|
| `docker build -t <tag> .` | Build Docker image from Dockerfile |
| `docker images` | List all local Docker images |
| `docker ps` | List running containers |
| `docker ps -a` | List all containers (including stopped) |
| `docker stop <container>` | Stop a running container |
| `docker start <container>` | Start a stopped container |
| `docker rm <container>` | Remove a stopped container |
| `docker rmi <image>` | Remove a Docker image |
| `docker logs <container>` | View container logs |
| `docker logs -f <container>` | Follow real-time container logs |
| `docker network create <net>` | Create a user-defined bridge network |
| `docker network ls` | List all Docker networks |
| `docker network inspect <net>` | Inspect network details and attached containers |
| `docker volume ls` | List all Docker volumes |
| `docker compose config` | Validate and display composed configuration |
| `docker compose up -d` | Build and start all services in background |
| `docker compose ps` | Show status of composed services |
| `docker compose logs` | View aggregated logs from all services |
| `docker compose logs <service>` | View logs from specific service |
| `docker compose down` | Stop and remove containers and networks |
| `docker compose down -v` | Stop, remove containers, networks, AND volumes |

---

## 12. Troubleshooting & Resolution Guide

| Issue | Root Cause | Resolution |
|-------|-----------|------------|
| `ECONNREFUSED` when Order calls User/Product | Order Service using `localhost` instead of Docker service name | Set `USER_SERVICE_URL=http://user-service:3001` via environment variable |
| `503 Service Unavailable` on order creation | Target dependency container is stopped or not on the same network | Restart the dependency: `docker start user-service` and ensure both are on `campus-network` |
| Port conflict on `3001`, `3002`, or `3003` | Another process or container is bound to the port | Stop conflicting process/container or change host port in `compose.yaml` |
| Data lost after container recreation | MongoDB running without volume mount | Verify `campus-mongo-data:/data/db` volume is configured in `compose.yaml` |
| Order Service starts before User/Product are ready | Docker `depends_on` only waits for container start, not application readiness | Robust error handling in Order Service returns `503` until dependencies are ready |
| `Cannot find module 'axios'` in Order Service | Dependencies not installed in container | Verify `package.json` includes axios and rebuild: `docker compose build order-service` |
| MongoDB connection timeout | MongoDB container not yet ready to accept connections | Add `restart: unless-stopped` to auto-retry; check MongoDB logs: `docker compose logs mongodb` |

---

## 13. How to Run Each Service Independently

Each service can be run standalone (outside Docker) for development:

```bash
# Terminal 1 — Start MongoDB locally or use Docker
docker run -d --name mongodb -p 27017:27017 mongo:latest

# Terminal 2 — User Service
cd user-service
npm install
PORT=3001 MONGO_URI=mongodb://localhost:27017/campusconnect-users node server.js

# Terminal 3 — Product Service
cd product-service
npm install
PORT=3002 MONGO_URI=mongodb://localhost:27017/campusconnect-products node server.js

# Terminal 4 — Order Service
cd order-service
npm install
PORT=3003 MONGO_URI=mongodb://localhost:27017/campusconnect-orders \
USER_SERVICE_URL=http://localhost:3001 \
PRODUCT_SERVICE_URL=http://localhost:3002 \
node server.js
```

---

## 14. Submission Checklist

| # | Item | Evidence |
|---|------|----------|
| 1 | At least three independently runnable services | `user-service/`, `product-service/`, `order-service/` directories |
| 2 | Each service exposes its own REST endpoints | Health check + CRUD endpoints per service |
| 3 | Each service has a Dockerfile and image | `Dockerfile` in each service directory |
| 4 | Services communicate through shared Docker network | `campus-network` bridge network |
| 5 | Internal service URLs use service names, not localhost | `http://user-service:3001`, `http://product-service:3002` |
| 6 | Database-per-service documented | Separate DB names in `MONGO_URI` |
| 7 | Docker Compose starts complete application | `docker compose up -d` |
| 8 | Order → User communication works | POST `/orders` validates userId via User Service |
| 9 | Order → Product communication works | POST `/orders` validates productId via Product Service |
| 10 | Dependency failure produces 503 | Stop user-service → POST `/orders` → 503 |
| 11 | Postman evidence covers direct & inter-service calls | `Microservices_Lab_6.postman_collection.json` |
| 12 | Architecture diagram matches implementation | Section 4 of this README |
| 13 | README documents setup, networking, testing, troubleshooting | This document |
| 14 | `compose.yaml` | Multi-service orchestration file |
| 15 | `.dockerignore` files | One per service |
| 16 | Environment variables without secrets | Configured in `compose.yaml` |

---

*End of Lab 6 Documentation — CampusConnect Microservices*