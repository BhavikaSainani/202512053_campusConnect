# CampusConnect - Lab 5: Docker & Containerization

**Course:** Web Services and Service-Oriented Architecture (SOA) Laboratory  
**Student ID:** 202512053  
**Tech Stack:** Docker | Docker Compose | Express.js (Node.js 20) | MongoDB | Postman  

---

## Table of Contents
1. [Project Overview & Relation to Lab 4](#1-project-overview--relation-to-lab-4)
2. [Docker Architecture & Container Workflow](#2-docker-architecture--container-workflow)
3. [Docker Installation & Verification](#3-docker-installation--verification)
4. [Step-by-Step Practical Implementation](#4-step-by-step-practical-implementation)
   - [Step 1: Baseline Lab 4 Student REST API Verification](#step-1--baseline-lab-4-student-rest-api-verification)
   - [Step 2: Dockerfile Creation & Layer Explanation](#step-2--dockerfile-creation--layer-explanation)
   - [Step 3: Building the Student API Docker Image](#step-3--building-the-student-api-docker-image)
   - [Step 4: Running the Student API Container & Port Mapping](#step-4--running-the-student-api-container--port-mapping)
   - [Step 5: Testing Containerized API with Postman](#step-5--testing-containerized-api-with-postman)
   - [Step 6: Running MongoDB as a Container](#step-6--running-mongodb-as-a-container)
   - [Step 7: Docker Networking & Inter-Container Communication](#step-7--docker-networking--inter-container-communication)
   - [Step 8: Environment Variables (`localhost` vs `mongodb`)](#step-8--environment-variables-localhost-vs-mongodb)
   - [Step 9: Docker Volume & MongoDB Persistence Verification](#step-9--docker-volume--mongodb-persistence-verification)
   - [Step 10: Multi-Container Orchestration with Docker Compose](#step-10--multi-container-orchestration-with-docker-compose)
   - [Step 11: Running & Verifying the Full Stack with Compose](#step-11--running--verifying-the-full-stack-with-compose)
   - [Step 12: Application Teardown & Clean Up](#step-12--application-teardown--clean-up)
5. [Basic Docker Commands Reference Table](#5-basic-docker-commands-reference-table)
6. [Troubleshooting & Resolution Guide](#6-troubleshooting--resolution-guide)
7. [Submission Evidence & Screenshot Checklist (Items 22–39)](#7-submission-evidence--screenshot-checklist-items-2239)

---

## 1. Project Overview & Relation to Lab 4

In **Lab 4**, we developed a multi-client Student REST API using Express.js and connected it to MongoDB Atlas cloud database, consumed by both a React web client and an Android mobile client.

In **Lab 5**, we transition the application from host-dependent execution to an isolated, reproducible **containerized microservice architecture**:
- Package the Express.js Student REST API into an immutable **Docker Image**.
- Replace the local/cloud MongoDB with a dedicated **MongoDB Docker Container**.
- Establish inter-container communication using a custom user-defined **Docker Bridge Network** (`student-network`).
- Decouple configuration using **Environment Variables** (`PORT`, `MONGO_URI`).
- Prevent data loss on container recreation by mounting a persistent named **Docker Volume** (`student-mongo-data`).
- Automate multi-container orchestration using **Docker Compose** (`compose.yaml`).

```
+---------------------------------------------------------------------------------------+
|                                    HOST MACHINE                                       |
|                                                                                       |
|   +-------------------+                     +--------------------+                    |
|   |  Postman / Client |                     |  Web Browser / UI  |                    |
|   +---------+---------+                     +---------+----------+                    |
|             | HTTP Request (port 3001)                | HTTP (port 3001)              |
|             +--------------------+--------------------+                               |
|                                  |                                                    |
|                                  v                                                    |
|   +-------------------------------------------------------------------------------+   |
|   |                  DOCKER ENGINE / DOCKER COMPOSE                               |   |
|   |                                                                               |   |
|   |   +-----------------------------------------------------------------------+   |   |
|   |   |            Docker Network: student-network (Bridge)                   |   |   |
|   |   |                                                                       |   |   |
|   |   |   +---------------------------+       +---------------------------+   |   |   |
|   |   |   | Container: student-api    |       | Container: mongodb        |   |   |   |
|   |   |   | Port: 3001:3001           |       | Port: 27017:27017         |   |   |   |
|   |   |   | Image: student-api:v1     | ----> | Image: mongo:latest       |   |   |   |
|   |   |   | Env: MONGO_URI=mongodb:// | DNS   | Host: mongodb:27017       |   |   |   |
|   |   |   |      mongodb:27017/...    |       | DB: campusconnect         |   |   |   |
|   |   |   +---------------------------+       +-------------+-------------+   |   |   |
|   |   |                                                     |                 |   |   |
|   |   +-----------------------------------------------------|-----------------+   |   |
|   |                                                         v                     |   |
|   |                            +----------------------------------------------+   |   |
|   |                            | Named Volume: student-mongo-data             |   |   |
|   |                            | Mount Path: /data/db (Persistent Storage)    |   |   |
|   |                            +----------------------------------------------+   |   |
|   +-------------------------------------------------------------------------------+   |
+---------------------------------------------------------------------------------------+
```

---

## 2. Docker Architecture & Container Workflow

```
[ Lab 4 Express Code ]  --->  [ Dockerfile ]  --->  docker build  --->  [ Image: student-api:v1 ]
                                                                                |
                                                                           docker run
                                                                                v
[ Named Volume: student-mongo-data ] <---> [ Mongo Container ] <---(student-network)---> [ API Container ]
```

---

## 3. Docker Installation & Verification

### Verification Commands
```bash
# Verify Docker CLI & Engine Version
docker --version

# Verify Docker Compose Version
docker compose version

# Run Hello-World Container to confirm engine functionality
docker run hello-world
```

---

## 4. Step-by-Step Practical Implementation

### Step 1 – Baseline Lab 4 Student REST API Verification
Before containerization, the API is verified running on local Node.js environment:
```bash
cd student-api-express
npm install
npm start
```
- Server starts at `http://localhost:3001`
- Endpoints verified via Postman: `GET /students`, `POST /students`, `GET /students/:id`, `PUT /students/:id`, `DELETE /students/:id`.

---

### Step 2 – Dockerfile Creation & Layer Explanation

The `Dockerfile` defines the automated recipe to build the container image:

```dockerfile
# 1. Base Image: Lightweight Node.js 20 on Alpine Linux
FROM node:20-alpine

# 2. Set Working Directory inside the container
WORKDIR /app

# 3. Copy package descriptors first to take advantage of Docker layer caching
COPY package*.json ./

# 4. Install dependencies inside container image
RUN npm install

# 5. Copy the rest of the application source code
COPY . .

# 6. Expose the application port
EXPOSE 3001

# 7. Start command for the container
CMD ["npm", "start"]
```

#### Layer Optimization Strategy:
By copying `package*.json` and running `npm install` before copying the rest of the source code, Docker caches the `node_modules` layer. Future source code edits will build in sub-seconds without re-installing npm dependencies.

A `.dockerignore` file is placed alongside to exclude non-essential files from the image context:
```
node_modules
npm-debug.log
.env
.git
.gitignore
```

---

### Step 3 – Building the Student API Docker Image

Build the Docker image tagged as `student-api:v1`:
```bash
# Build from directory containing the Dockerfile
docker build -t student-api:v1 .

# Inspect built local Docker images
docker images
```

---

### Step 4 – Running the Student API Container & Port Mapping

Run the container in detached mode with host port mapping:
```bash
# Run container with port forwarding 3001:3001
docker run -d --name student-api -p 3001:3001 student-api:v1

# Check running containers
docker ps
```

#### Port Mapping Explanation (`-p 3001:3001`):
- **Host Port (Left `3001`)**: The port exposed on the physical host machine, accessible to Postman, curl, and web browsers.
- **Container Port (Right `3001`)**: The port inside the container's isolated network namespace where Express is listening.

---

### Step 5 – Testing Containerized API with Postman

Send HTTP requests to `http://localhost:3001`:

| Request | Method | Endpoint | Expected Status | Description |
|---|---|---|---|---|
| **Root Health** | `GET` | `/` | `200 OK` | Confirms containerized API is running |
| **Get All** | `GET` | `/students` | `200 OK` | Retrieves all student records |
| **Create** | `POST` | `/students` | `201 Created` | Inserts new student record |
| **Constraint** | `POST` | `/students` | `400 Bad Request` | Enforces unique email check |
| **Get by ID** | `GET` | `/students/:id` | `200 OK` | Retrieves single student by ID |
| **Update** | `PUT` | `/students/:id` | `200 OK` | Updates student details |
| **Partial** | `PATCH` | `/students/:id` | `200 OK` | Partial update (e.g. semester) |
| **Delete** | `DELETE` | `/students/:id` | `200 OK` | Deletes student record |

---

### Step 6 – Running MongoDB as a Container

Run the official MongoDB container:
```bash
# Pull official MongoDB image
docker pull mongo:latest

# Run standalone MongoDB container
docker run -d --name mongodb -p 27017:27017 mongo:latest

# Verify MongoDB is running
docker ps
```

---

### Step 7 – Docker Networking & Inter-Container Communication

Containers exist in isolated network namespaces. To communicate directly without exposing internal ports to the host:

```bash
# 1. Create a dedicated user-defined bridge network
docker network create student-network

# 2. Connect the MongoDB container to the network
docker network connect student-network mongodb

# 3. Connect the Student API container to the network
docker network connect student-network student-api

# 4. Inspect the network to confirm both containers are attached
docker network inspect student-network
```

---

### Step 8 – Environment Variables (`localhost` vs `mongodb`)

#### Why `localhost` Fails Inside Containers:
Inside the `student-api` container, `localhost` resolves to the container itself (`127.0.0.1`), NOT the host machine or the MongoDB container. Attempting `mongodb://localhost:27017` triggers `ECONNREFUSED`.

#### Docker DNS Resolution:
Within a user-defined Docker bridge network (`student-network`), Docker provides an automatic embedded DNS server. The hostname `mongodb` automatically resolves to the IP address assigned to the `mongodb` container.

```bash
# Run API container with environment variables injected
docker run -d --name student-api \
  --network student-network \
  -p 3001:3001 \
  -e PORT=3001 \
  -e MONGO_URI=mongodb://mongodb:27017/campusconnect \
  student-api:v1
```

---

### Step 9 – Docker Volume & MongoDB Persistence Verification

By default, container filesystems are ephemeral (stored in the temporary writable container layer). To persist MongoDB data across container destructions and upgrades:

```bash
# 1. Create named Docker volume
docker volume create student-mongo-data

# 2. Inspect created volume
docker volume ls

# 3. Run MongoDB with the volume mounted to /data/db
docker run -d --name mongodb \
  --network student-network \
  -v student-mongo-data:/data/db \
  mongo:latest
```

#### Persistence Verification Exercise:
1. **Insert Record**: Make a `POST /students` request to create student `Bhavika Sainani` (`bhavika@example.com`).
2. **Confirm Retrieval**: `GET /students` returns the newly created record with HTTP 200.
3. **Destroy Container**:
   ```bash
   docker stop mongodb
   docker rm mongodb
   ```
4. **Recreate Container** using the same volume:
   ```bash
   docker run -d --name mongodb \
     --network student-network \
     -v student-mongo-data:/data/db \
     mongo:latest
   ```
5. **Verify Persistence**: Execute `GET /students` via Postman. The student record is retrieved successfully, proving data survived container destruction.

---

### Step 10 – Multi-Container Orchestration with Docker Compose

Instead of executing multiple manual Docker CLI commands, `compose.yaml` declares the entire multi-container stack, networking, and volumes declaratively:

```yaml
services:
  api:
    build:
      context: .
      dockerfile: Dockerfile
    container_name: student-api
    ports:
      - "3001:3001"
    environment:
      PORT: 3001
      MONGO_URI: mongodb://mongodb:27017/campusconnect
    depends_on:
      - mongodb
    networks:
      - student-network
    restart: unless-stopped

  mongodb:
    image: mongo:latest
    container_name: mongodb
    ports:
      - "27017:27017"
    volumes:
      - student-mongo-data:/data/db
    networks:
      - student-network
    restart: unless-stopped

volumes:
  student-mongo-data:
    name: student-mongo-data

networks:
  student-network:
    name: student-network
    driver: bridge
```

---

### Step 11 – Running & Verifying the Full Stack with Compose

```bash
# Start all services in detached mode (builds images if necessary)
docker compose up -d

# Verify all services are running and healthy
docker compose ps

# View unified real-time logs from all services
docker compose logs -f

# View logs specifically from API service
docker compose logs api
```

#### Postman Testing Flow:
`Postman` &rarr; `http://localhost:3001/students` &rarr; `student-api` Container &rarr; `mongodb` Container &rarr; `student-mongo-data` Volume.

---

### Step 12 – Application Teardown & Clean Up

```bash
# Stop and remove containers and networks (preserves persistent volumes)
docker compose down

# To also remove volumes (when doing a fresh start):
# docker compose down -v
```

---

## 5. Basic Docker Commands Reference Table

| Command | Purpose |
|---|---|
| `docker --version` | Checks Docker installation and CLI version |
| `docker images` | Lists all locally stored Docker images with tags and sizes |
| `docker ps` | Lists all currently running containers and their port mappings |
| `docker ps -a` | Lists all containers including stopped and exited ones |
| `docker build -t <tag> .` | Builds a Docker image from a `Dockerfile` in the current context |
| `docker run -d -p <host>:<ctr> --name <name> <img_tag>` | Creates and starts a container with port mapping in detached mode |
| `docker stop <container>` | Gracefully stops a running container (`SIGTERM` &rarr; `SIGKILL`) |
| `docker start <container>` | Starts an existing stopped container |
| `docker restart <container>` | Restarts a container |
| `docker rm <container>` | Removes a stopped container |
| `docker rmi <image>` | Removes a local Docker image |
| `docker logs <container>` | Views stdout/stderr log stream from a container |
| `docker logs -f <container>` | Follows real-time logs from a container |
| `docker network ls` | Lists all Docker networks (bridge, host, none, custom) |
| `docker network create <net>` | Creates a new user-defined bridge network |
| `docker network connect <net> <ctr>` | Connects a container to a Docker network |
| `docker volume ls` | Lists all persistent Docker volumes |
| `docker volume create <vol>` | Creates a named persistent storage volume |
| `docker compose up -d` | Builds, creates, and starts all services in background |
| `docker compose ps` | Displays status and port bindings of compose services |
| `docker compose logs` | Aggregates and displays output from all compose containers |
| `docker compose down` | Stops and tears down containers, networks, and links created by compose |

---

## 6. Troubleshooting & Resolution Guide

| Issue Encountered | Root Cause | Resolution Applied |
|---|---|---|
| `ECONNREFUSED 127.0.0.1:27017` | API container attempted connecting to `localhost:27017` instead of MongoDB container | Set `MONGO_URI=mongodb://mongodb:27017/campusconnect` and attached both containers to `student-network` bridge. |
| Port conflict `3001` or `27017` already in use | Another local service or previous container was bound to the port | Identified and stopped competing process via `docker stop <container>` or updated host port mapping in `compose.yaml`. |
| Data lost upon container recreation | MongoDB container was running without volume mount, saving data only in container writable layer | Attached persistent named volume `student-mongo-data:/data/db` in container run and `compose.yaml`. |
| `docker: command not found` | Docker Desktop not running or Docker CLI not added to system PATH | Launched Docker Desktop, ensured WSL2 engine integration was active, and verified with `docker --version`. |
| API container crashed on start | Express server attempting to start before MongoDB was ready to accept connections | Added `depends_on: - mongodb` in `compose.yaml` and robust Mongoose error handling in `server.js`. |

---

## 7. Submission Evidence & Screenshot Checklist (Items 22–39)

| # | Submission Item | Evidence / Command | Expected Verification |
|---|---|---|---|
| **22** | Docker installation/version | `docker --version` | Displays Docker CLI version |
| **23** | Lab 4 API running before Dockerization | `npm start` in `student-api-express` | Console shows running at `http://localhost:3001` |
| **24** | Dockerfile | View `Dockerfile` | Multi-stage/layered file with node:20, WORKDIR, COPY, RUN, EXPOSE, CMD |
| **25** | Successful image build | `docker build -t student-api:v1 .` | Build completed successfully with tag `student-api:v1` |
| **26** | `docker images` output | `docker images` | Lists `student-api:v1` and `mongo` |
| **27** | Running API container (`docker ps`) | `docker ps` | Container `student-api` running on `0.0.0.0:3001->3001/tcp` |
| **28** | Postman testing containerized API | Postman `GET /students`, `POST /students` | HTTP 200 / 201 responses from container |
| **29** | MongoDB container running | `docker ps` | Container `mongodb` running |
| **30** | Docker network showing both containers | `docker network inspect student-network` | Shows `student-api` and `mongodb` attached with assigned IPv4s |
| **31** | `MONGO_URI` using service name | Inspect environment variables | `MONGO_URI=mongodb://mongodb:27017/campusconnect` |
| **32** | Environment variable configuration | Injected via `-e` or `compose.yaml` | `PORT=3001`, `MONGO_URI` loaded correctly |
| **33** | MongoDB volume creation/mounting | `docker volume ls` | Volume `student-mongo-data` created and mounted to `/data/db` |
| **34** | Persistence test across container recreation | Stop/remove mongo, restart mongo, `GET /students` | Data remains intact after container replacement |
| **35** | Compose configuration | View `compose.yaml` | Declares `api`, `mongodb`, `student-network`, `student-mongo-data` |
| **36** | Successful `docker compose up` | `docker compose up -d` | All services created and started in background |
| **37** | `docker compose ps` output | `docker compose ps` | Both `student-api` and `mongodb` show status `Up` |
| **38** | Postman testing of Compose application | Full CRUD requests via Postman | All 5 operations succeed against compose stack |
| **39** | Docker/Compose logs | `docker compose logs` | Express connected to MongoDB; incoming requests logged |