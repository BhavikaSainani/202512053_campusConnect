# Lab 5 Screenshot Evidence Index

Save all required submission screenshots (Items 22 through 39) in this folder according to the naming convention below:

| # | Filename | Description / Command to Capture |
|---|---|---|
| **22** | `22_docker_version.png` | `docker --version` and `docker compose version` output in terminal |
| **23** | `23_lab4_api_running.png` | Lab 4 API running locally before dockerization (`npm start` in `student-api-express`) |
| **24** | `24_dockerfile.png` | IDE view of `student-api-express/Dockerfile` |
| **25** | `25_docker_build.png` | Terminal output of successful `docker build -t student-api:v1 ./student-api-express` |
| **26** | `26_docker_images.png` | Terminal output of `docker images` showing `student-api:v1` |
| **27** | `27_docker_ps_api.png` | Terminal output of `docker ps` showing running `student-api` container with port `3001` |
| **28** | `28_postman_container_api.png` | Postman calling containerized REST API (`GET /students` and `POST /students`) |
| **29** | `29_docker_ps_mongodb.png` | Terminal output of `docker ps` showing running `mongodb` container |
| **30** | `30_docker_network_inspect.png` | Terminal output of `docker network inspect student-network` showing both containers connected |
| **31** | `31_mongo_uri_config.png` | View of `MONGO_URI=mongodb://mongodb:27017/campusconnect` configuration |
| **32** | `32_env_vars.png` | Terminal / config showing environment variables passed to container |
| **33** | `33_docker_volume_ls.png` | Terminal output of `docker volume ls` and volume inspection for `student-mongo-data` |
| **34** | `34_persistence_test.png` | Postman `GET /students` proving data remains intact after MongoDB container recreation |
| **35** | `35_compose_yaml.png` | IDE view of `compose.yaml` |
| **36** | `36_docker_compose_up.png` | Terminal output of `docker compose up -d` starting both services |
| **37** | `37_docker_compose_ps.png` | Terminal output of `docker compose ps` showing both services `Up` |
| **38** | `38_postman_compose_full_crud.png` | Postman executing CRUD requests against Docker Compose stack |
| **39** | `39_docker_compose_logs.png` | Terminal output of `docker compose logs` showing API & Mongo connected |
